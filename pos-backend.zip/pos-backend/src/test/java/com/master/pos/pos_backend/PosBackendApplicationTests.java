package com.master.pos.pos_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PosBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
